﻿namespace pizza
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.custInfoTab = new System.Windows.Forms.TabControl();
            this.pizzaTab = new System.Windows.Forms.TabPage();
            this.toppingsLabel = new System.Windows.Forms.Label();
            this.hamBox = new System.Windows.Forms.CheckBox();
            this.sausageBox1 = new System.Windows.Forms.CheckBox();
            this.jalapenoBox1 = new System.Windows.Forms.CheckBox();
            this.onionBox = new System.Windows.Forms.CheckBox();
            this.xcheeseBox = new System.Windows.Forms.CheckBox();
            this.pepCheck = new System.Windows.Forms.CheckBox();
            this.crustLabel = new System.Windows.Forms.Label();
            this.crustBox = new System.Windows.Forms.ComboBox();
            this.sizeLabel = new System.Windows.Forms.Label();
            this.sizeBox = new System.Windows.Forms.ComboBox();
            this.drinksTab = new System.Windows.Forms.TabPage();
            this.literLabel = new System.Windows.Forms.Label();
            this.QntyLabel = new System.Windows.Forms.Label();
            this.pepsiQnty = new System.Windows.Forms.NumericUpDown();
            this.spriteQnty = new System.Windows.Forms.NumericUpDown();
            this.dpQnty = new System.Windows.Forms.NumericUpDown();
            this.mtnDQnty = new System.Windows.Forms.NumericUpDown();
            this.PepsiLabel = new System.Windows.Forms.Label();
            this.spriteLabel = new System.Windows.Forms.Label();
            this.dpLabel = new System.Windows.Forms.Label();
            this.mtnDewLabel = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.orderButton = new System.Windows.Forms.Button();
            this.phoneBox = new System.Windows.Forms.TextBox();
            this.nameBox = new System.Windows.Forms.TextBox();
            this.addressBox = new System.Windows.Forms.TextBox();
            this.phoneLabel = new System.Windows.Forms.Label();
            this.delivLabel = new System.Windows.Forms.Label();
            this.nameLabel = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.custInfoTab.SuspendLayout();
            this.pizzaTab.SuspendLayout();
            this.drinksTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pepsiQnty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spriteQnty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dpQnty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mtnDQnty)).BeginInit();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // custInfoTab
            // 
            this.custInfoTab.Controls.Add(this.pizzaTab);
            this.custInfoTab.Controls.Add(this.drinksTab);
            this.custInfoTab.Controls.Add(this.tabPage1);
            this.custInfoTab.Location = new System.Drawing.Point(1, 0);
            this.custInfoTab.Name = "custInfoTab";
            this.custInfoTab.SelectedIndex = 0;
            this.custInfoTab.Size = new System.Drawing.Size(802, 449);
            this.custInfoTab.TabIndex = 4;
            // 
            // pizzaTab
            // 
            this.pizzaTab.AllowDrop = true;
            this.pizzaTab.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pizzaTab.BackgroundImage = global::pizza.Properties.Resources.eb0321b1_ac0a_4a8e_93ab_d79b4bfc88d9;
            this.pizzaTab.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pizzaTab.Controls.Add(this.toppingsLabel);
            this.pizzaTab.Controls.Add(this.hamBox);
            this.pizzaTab.Controls.Add(this.sausageBox1);
            this.pizzaTab.Controls.Add(this.jalapenoBox1);
            this.pizzaTab.Controls.Add(this.onionBox);
            this.pizzaTab.Controls.Add(this.xcheeseBox);
            this.pizzaTab.Controls.Add(this.pepCheck);
            this.pizzaTab.Controls.Add(this.crustLabel);
            this.pizzaTab.Controls.Add(this.crustBox);
            this.pizzaTab.Controls.Add(this.sizeLabel);
            this.pizzaTab.Controls.Add(this.sizeBox);
            this.pizzaTab.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pizzaTab.Location = new System.Drawing.Point(4, 25);
            this.pizzaTab.Name = "pizzaTab";
            this.pizzaTab.Padding = new System.Windows.Forms.Padding(3);
            this.pizzaTab.Size = new System.Drawing.Size(794, 420);
            this.pizzaTab.TabIndex = 0;
            this.pizzaTab.Text = "pizza";
            // 
            // toppingsLabel
            // 
            this.toppingsLabel.AutoSize = true;
            this.toppingsLabel.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.toppingsLabel.Location = new System.Drawing.Point(603, 18);
            this.toppingsLabel.Name = "toppingsLabel";
            this.toppingsLabel.Size = new System.Drawing.Size(104, 16);
            this.toppingsLabel.TabIndex = 10;
            this.toppingsLabel.Text = "toppings ($1.00):";
            // 
            // hamBox
            // 
            this.hamBox.AutoSize = true;
            this.hamBox.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.hamBox.Location = new System.Drawing.Point(603, 180);
            this.hamBox.Name = "hamBox";
            this.hamBox.Size = new System.Drawing.Size(58, 20);
            this.hamBox.TabIndex = 9;
            this.hamBox.Text = "Ham";
            this.hamBox.UseVisualStyleBackColor = false;
            // 
            // sausageBox1
            // 
            this.sausageBox1.AutoSize = true;
            this.sausageBox1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.sausageBox1.Location = new System.Drawing.Point(603, 154);
            this.sausageBox1.Name = "sausageBox1";
            this.sausageBox1.Size = new System.Drawing.Size(84, 20);
            this.sausageBox1.TabIndex = 8;
            this.sausageBox1.Text = "Sausage";
            this.sausageBox1.UseVisualStyleBackColor = false;
            // 
            // jalapenoBox1
            // 
            this.jalapenoBox1.AutoSize = true;
            this.jalapenoBox1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.jalapenoBox1.Location = new System.Drawing.Point(603, 128);
            this.jalapenoBox1.Name = "jalapenoBox1";
            this.jalapenoBox1.Size = new System.Drawing.Size(86, 20);
            this.jalapenoBox1.TabIndex = 7;
            this.jalapenoBox1.Text = "Jalapeño";
            this.jalapenoBox1.UseVisualStyleBackColor = false;
            // 
            // onionBox
            // 
            this.onionBox.AutoSize = true;
            this.onionBox.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.onionBox.Location = new System.Drawing.Point(603, 102);
            this.onionBox.Name = "onionBox";
            this.onionBox.Size = new System.Drawing.Size(71, 20);
            this.onionBox.TabIndex = 6;
            this.onionBox.Text = "Onions";
            this.onionBox.UseVisualStyleBackColor = false;
            // 
            // xcheeseBox
            // 
            this.xcheeseBox.AutoSize = true;
            this.xcheeseBox.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.xcheeseBox.Location = new System.Drawing.Point(603, 76);
            this.xcheeseBox.Name = "xcheeseBox";
            this.xcheeseBox.Size = new System.Drawing.Size(109, 20);
            this.xcheeseBox.TabIndex = 5;
            this.xcheeseBox.Text = "Extra Cheese";
            this.xcheeseBox.UseVisualStyleBackColor = false;
            // 
            // pepCheck
            // 
            this.pepCheck.AutoSize = true;
            this.pepCheck.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.pepCheck.Location = new System.Drawing.Point(603, 50);
            this.pepCheck.Name = "pepCheck";
            this.pepCheck.Size = new System.Drawing.Size(92, 20);
            this.pepCheck.TabIndex = 4;
            this.pepCheck.Text = "Pepperoni";
            this.pepCheck.UseVisualStyleBackColor = false;
            // 
            // crustLabel
            // 
            this.crustLabel.AutoSize = true;
            this.crustLabel.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.crustLabel.Location = new System.Drawing.Point(226, 171);
            this.crustLabel.Name = "crustLabel";
            this.crustLabel.Size = new System.Drawing.Size(37, 16);
            this.crustLabel.TabIndex = 3;
            this.crustLabel.Text = "Crust";
            // 
            // crustBox
            // 
            this.crustBox.FormattingEnabled = true;
            this.crustBox.Items.AddRange(new object[] {
            "Handtoss",
            "Thin",
            "Deep Dish"});
            this.crustBox.Location = new System.Drawing.Point(162, 190);
            this.crustBox.Name = "crustBox";
            this.crustBox.Size = new System.Drawing.Size(190, 24);
            this.crustBox.TabIndex = 2;
            // 
            // sizeLabel
            // 
            this.sizeLabel.AutoSize = true;
            this.sizeLabel.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.sizeLabel.Location = new System.Drawing.Point(226, 105);
            this.sizeLabel.Name = "sizeLabel";
            this.sizeLabel.Size = new System.Drawing.Size(33, 16);
            this.sizeLabel.TabIndex = 1;
            this.sizeLabel.Text = "Size";
            // 
            // sizeBox
            // 
            this.sizeBox.FormattingEnabled = true;
            this.sizeBox.Items.AddRange(new object[] {
            "Small (8\") - $10.00",
            "Medium (10\") - $12.00",
            "Large (12\") - $14.00",
            "XLarge (15\") - $17.00"});
            this.sizeBox.Location = new System.Drawing.Point(162, 124);
            this.sizeBox.Name = "sizeBox";
            this.sizeBox.Size = new System.Drawing.Size(190, 24);
            this.sizeBox.TabIndex = 0;
            // 
            // drinksTab
            // 
            this.drinksTab.BackColor = System.Drawing.Color.White;
            this.drinksTab.BackgroundImage = global::pizza.Properties.Resources.eb0321b1_ac0a_4a8e_93ab_d79b4bfc88d9;
            this.drinksTab.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.drinksTab.Controls.Add(this.literLabel);
            this.drinksTab.Controls.Add(this.QntyLabel);
            this.drinksTab.Controls.Add(this.pepsiQnty);
            this.drinksTab.Controls.Add(this.spriteQnty);
            this.drinksTab.Controls.Add(this.dpQnty);
            this.drinksTab.Controls.Add(this.mtnDQnty);
            this.drinksTab.Controls.Add(this.PepsiLabel);
            this.drinksTab.Controls.Add(this.spriteLabel);
            this.drinksTab.Controls.Add(this.dpLabel);
            this.drinksTab.Controls.Add(this.mtnDewLabel);
            this.drinksTab.Location = new System.Drawing.Point(4, 25);
            this.drinksTab.Name = "drinksTab";
            this.drinksTab.Padding = new System.Windows.Forms.Padding(3);
            this.drinksTab.Size = new System.Drawing.Size(794, 420);
            this.drinksTab.TabIndex = 1;
            this.drinksTab.Text = "drinks";
            // 
            // literLabel
            // 
            this.literLabel.AutoSize = true;
            this.literLabel.Location = new System.Drawing.Point(265, 56);
            this.literLabel.Name = "literLabel";
            this.literLabel.Size = new System.Drawing.Size(49, 16);
            this.literLabel.TabIndex = 9;
            this.literLabel.Text = "2 Liters";
            // 
            // QntyLabel
            // 
            this.QntyLabel.AutoSize = true;
            this.QntyLabel.Location = new System.Drawing.Point(431, 56);
            this.QntyLabel.Name = "QntyLabel";
            this.QntyLabel.Size = new System.Drawing.Size(100, 16);
            this.QntyLabel.TabIndex = 8;
            this.QntyLabel.Text = "Quantity ($2.00):";
            // 
            // pepsiQnty
            // 
            this.pepsiQnty.Location = new System.Drawing.Point(431, 190);
            this.pepsiQnty.Name = "pepsiQnty";
            this.pepsiQnty.Size = new System.Drawing.Size(120, 22);
            this.pepsiQnty.TabIndex = 7;
            // 
            // spriteQnty
            // 
            this.spriteQnty.Location = new System.Drawing.Point(431, 162);
            this.spriteQnty.Name = "spriteQnty";
            this.spriteQnty.Size = new System.Drawing.Size(120, 22);
            this.spriteQnty.TabIndex = 6;
            // 
            // dpQnty
            // 
            this.dpQnty.Location = new System.Drawing.Point(431, 132);
            this.dpQnty.Name = "dpQnty";
            this.dpQnty.Size = new System.Drawing.Size(120, 22);
            this.dpQnty.TabIndex = 5;
            // 
            // mtnDQnty
            // 
            this.mtnDQnty.Location = new System.Drawing.Point(431, 102);
            this.mtnDQnty.Name = "mtnDQnty";
            this.mtnDQnty.Size = new System.Drawing.Size(120, 22);
            this.mtnDQnty.TabIndex = 4;
            // 
            // PepsiLabel
            // 
            this.PepsiLabel.AutoSize = true;
            this.PepsiLabel.Location = new System.Drawing.Point(142, 189);
            this.PepsiLabel.Name = "PepsiLabel";
            this.PepsiLabel.Size = new System.Drawing.Size(45, 16);
            this.PepsiLabel.TabIndex = 3;
            this.PepsiLabel.Text = "Pepsi:";
            // 
            // spriteLabel
            // 
            this.spriteLabel.AutoSize = true;
            this.spriteLabel.Location = new System.Drawing.Point(142, 162);
            this.spriteLabel.Name = "spriteLabel";
            this.spriteLabel.Size = new System.Drawing.Size(45, 16);
            this.spriteLabel.TabIndex = 2;
            this.spriteLabel.Text = "Sprite:";
            // 
            // dpLabel
            // 
            this.dpLabel.AutoSize = true;
            this.dpLabel.Location = new System.Drawing.Point(142, 132);
            this.dpLabel.Name = "dpLabel";
            this.dpLabel.Size = new System.Drawing.Size(75, 16);
            this.dpLabel.TabIndex = 1;
            this.dpLabel.Text = "Dr. Pepper:";
            // 
            // mtnDewLabel
            // 
            this.mtnDewLabel.AutoSize = true;
            this.mtnDewLabel.Location = new System.Drawing.Point(142, 102);
            this.mtnDewLabel.Name = "mtnDewLabel";
            this.mtnDewLabel.Size = new System.Drawing.Size(94, 16);
            this.mtnDewLabel.TabIndex = 0;
            this.mtnDewLabel.Text = "Mountain Dew:";
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.BackgroundImage = global::pizza.Properties.Resources.eb0321b1_ac0a_4a8e_93ab_d79b4bfc88d9;
            this.tabPage1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage1.Controls.Add(this.orderButton);
            this.tabPage1.Controls.Add(this.phoneBox);
            this.tabPage1.Controls.Add(this.nameBox);
            this.tabPage1.Controls.Add(this.addressBox);
            this.tabPage1.Controls.Add(this.phoneLabel);
            this.tabPage1.Controls.Add(this.delivLabel);
            this.tabPage1.Controls.Add(this.nameLabel);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(794, 420);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "customer info";
            // 
            // orderButton
            // 
            this.orderButton.Location = new System.Drawing.Point(140, 298);
            this.orderButton.Name = "orderButton";
            this.orderButton.Size = new System.Drawing.Size(417, 23);
            this.orderButton.TabIndex = 6;
            this.orderButton.Text = "Place Order!";
            this.orderButton.UseVisualStyleBackColor = true;
            this.orderButton.Click += new System.EventHandler(this.orderButton_Click);
            // 
            // phoneBox
            // 
            this.phoneBox.Location = new System.Drawing.Point(327, 176);
            this.phoneBox.Name = "phoneBox";
            this.phoneBox.Size = new System.Drawing.Size(230, 22);
            this.phoneBox.TabIndex = 5;
            // 
            // nameBox
            // 
            this.nameBox.Location = new System.Drawing.Point(327, 86);
            this.nameBox.Name = "nameBox";
            this.nameBox.Size = new System.Drawing.Size(230, 22);
            this.nameBox.TabIndex = 4;
            // 
            // addressBox
            // 
            this.addressBox.Location = new System.Drawing.Point(327, 132);
            this.addressBox.Name = "addressBox";
            this.addressBox.Size = new System.Drawing.Size(230, 22);
            this.addressBox.TabIndex = 3;
            // 
            // phoneLabel
            // 
            this.phoneLabel.AutoSize = true;
            this.phoneLabel.Location = new System.Drawing.Point(135, 182);
            this.phoneLabel.Name = "phoneLabel";
            this.phoneLabel.Size = new System.Drawing.Size(52, 16);
            this.phoneLabel.TabIndex = 2;
            this.phoneLabel.Text = "Phone: ";
            // 
            // delivLabel
            // 
            this.delivLabel.AutoSize = true;
            this.delivLabel.Location = new System.Drawing.Point(135, 132);
            this.delivLabel.Name = "delivLabel";
            this.delivLabel.Size = new System.Drawing.Size(61, 16);
            this.delivLabel.TabIndex = 1;
            this.delivLabel.Text = "Address:";
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(137, 86);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(50, 16);
            this.nameLabel.TabIndex = 0;
            this.nameLabel.Text = "Name: ";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(273, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(8, 8);
            this.button1.TabIndex = 5;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.custInfoTab);
            this.Name = "Form1";
            this.Text = "Schafer\'s Pizzaria";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.custInfoTab.ResumeLayout(false);
            this.pizzaTab.ResumeLayout(false);
            this.pizzaTab.PerformLayout();
            this.drinksTab.ResumeLayout(false);
            this.drinksTab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pepsiQnty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spriteQnty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dpQnty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mtnDQnty)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl custInfoTab;
        private System.Windows.Forms.TabPage pizzaTab;
        private System.Windows.Forms.TabPage drinksTab;
        private System.Windows.Forms.ComboBox sizeBox;
        private System.Windows.Forms.Label sizeLabel;
        private System.Windows.Forms.Label crustLabel;
        private System.Windows.Forms.ComboBox crustBox;
        private System.Windows.Forms.CheckBox pepCheck;
        private System.Windows.Forms.CheckBox hamBox;
        private System.Windows.Forms.CheckBox sausageBox1;
        private System.Windows.Forms.CheckBox jalapenoBox1;
        private System.Windows.Forms.CheckBox onionBox;
        private System.Windows.Forms.CheckBox xcheeseBox;
        private System.Windows.Forms.Label toppingsLabel;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label dpLabel;
        private System.Windows.Forms.Label mtnDewLabel;
        private System.Windows.Forms.NumericUpDown pepsiQnty;
        private System.Windows.Forms.NumericUpDown spriteQnty;
        private System.Windows.Forms.NumericUpDown dpQnty;
        private System.Windows.Forms.NumericUpDown mtnDQnty;
        private System.Windows.Forms.Label PepsiLabel;
        private System.Windows.Forms.Label spriteLabel;
        private System.Windows.Forms.Label literLabel;
        private System.Windows.Forms.Label QntyLabel;
        private System.Windows.Forms.Label phoneLabel;
        private System.Windows.Forms.Label delivLabel;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Button orderButton;
        private System.Windows.Forms.TextBox phoneBox;
        private System.Windows.Forms.TextBox nameBox;
        private System.Windows.Forms.TextBox addressBox;
    }
}

