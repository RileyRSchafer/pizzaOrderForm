﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace pizza
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

       

        private void Form1_Load(object sender, EventArgs e)
        {
            this.sizeBox.SelectedIndex = 0;
            this.crustBox.SelectedIndex = 0;
        }

       // Small(8") - $10.00
       // Medium (10") - $12.00
       // Large (12") - $14.00
       // XLarge (15") - $17.00
        private void orderButton_Click(object sender, EventArgs e)
        {
            double total = 0.00;
            // pizza size check
                    if(this.sizeBox.SelectedIndex == 0)
                    {
                        total = total + 10;
                    }else if (this.sizeBox.SelectedIndex == 1) {
                        total = total + 12;
                    }
                    else if (this.sizeBox.SelectedIndex == 2) {
                        total = total + 14;
                    }
                    else {
                        total = total + 17;
                    }
            // Toppings check
            string toppings = "";
                    if (this.pepCheck.Checked == true) { total = total + 1; toppings = toppings + "Peperoni\n"; }
                    if (this.xcheeseBox.Checked == true) { total = total + 1; toppings = toppings + "Extra Cheese\n"; }
                    if (this.onionBox.Checked == true) { total = total + 1; toppings = toppings + "Onions\n"; }
            if (this.jalapenoBox1.Checked == true) { total = total + 1; toppings = toppings + "Jalapenos\n"; }
                    if (this.sausageBox1.Checked == true) { total = total + 1; toppings = toppings + "Sausage\n"; }
                    if (this.hamBox.Checked == true) { total = total + 1; toppings = toppings + "Ham\n"; }
            // beverages
            string drinks = "";
                    total = ((double)(this.mtnDQnty.Value * 2) + total);
                        if(this.mtnDQnty.Value > 0) { drinks = drinks + "Mtn Dew: " + this.mtnDQnty.Value + "\n"; }
                    total = ((double)(this.dpQnty.Value * 2) + total);
                         if (this.dpQnty.Value > 0)
                        {
                            drinks = drinks + "dr. Pep: " + this.dpQnty.Value + "\n";
                        }
                total = ((double)(this.pepsiQnty.Value * 2) + total);
                        if (this.pepsiQnty.Value > 0)
                        {
                            drinks = drinks + "Pepsi: " + this.pepsiQnty.Value + "\n";
                        }
                total = ((double)(this.spriteQnty.Value * 2) + total);
            if (this.spriteQnty.Value > 0)
            {
                drinks = drinks + "Sprite: " + this.spriteQnty.Value + "\n";
            }
                // check cust info boxes
                string error = "Error";
                    string errormsg = "Please ensure all boxes are filled.";
                    if (this.nameBox.Text == null) { MessageBox.Show(errormsg, error); }
                    else if (this.addressBox.Text == "") { MessageBox.Show(errormsg, error); }
                    else if (this.phoneBox.Text == "") { MessageBox.Show(errormsg, error); }
                    else
                    {
                        string message = "Schafer's Pizzaria                                                                                 \n555 15th st\n555-555-5555\nRecipt\n\nName: "  + this.nameBox.Text + "\n" + "Delivering to: " + this.addressBox.Text + "Cust contact: " + this.phoneBox.Text + "\n\n" + "Size: " + this.sizeBox.Text + "Crust: " + this.crustBox.Text +  "\n\n Toppings: \n\n" + toppings + "\n\nDrinks: \n" + drinks + "\n\nTotal: $" + total + "\n";
                        string title = "Recipt";
                        MessageBox.Show(message, title);
                    }
        }

    
    }
}
